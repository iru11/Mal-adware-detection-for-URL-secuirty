package com.learning.phisingdetection.service;

public class PhisingDetection {
}
