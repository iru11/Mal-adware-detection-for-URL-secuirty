package com.learning.phisingdetection.service;

public class InvalidURLException extends RuntimeException {
}
